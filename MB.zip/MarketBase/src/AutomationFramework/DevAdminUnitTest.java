package AutomationFramework;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class DevAdminUnitTest {
	public static void main(String args[]) throws InterruptedException{
		
		WebDriver driver;
		
		System.setProperty("webdriver.gecko.driver", "E:\\Selenium\\geckodriver-v0.17.0-win64\\geckodriver.exe");
		
		driver = new FirefoxDriver();
		   
	    //Launch the Online Store Website
		
//		String path = "http://marketbase.net.au";
	    driver.get("http://www.marketbase.net.au");
	    
	    //user name
	    driver.findElement(By.id("MainContent_LoginForm1_UserName")).sendKeys("superadmin1");
	    	    
	    //Password
	    driver.findElement(By.id("MainContent_LoginForm1_Password")).sendKeys("bachmann");
	    
	    //Submit
	    driver.findElement(By.name("ctl00$MainContent$LoginForm1$ctl01")).click();
	    
	    System.out.println("Success fully logged IN super Admin");
	    Thread.sleep(3000);
	    
	    driver.manage().window().maximize();
	    Thread.sleep(5000);
	    
	    //Home
	    System.out.println(driver.findElement(By.id("content")).getText());
	    
	    //Users
	    driver.findElement(By.id("linkagent")).click();
	    Thread.sleep(2000);
	    System.out.println("Successfully opened all the User menu");
	    System.out.println(driver.findElement(By.xpath(".//*[@id='content']/div[1]/div[1]")).getText());
	    
	  //Entities
	    driver.findElement(By.id("EntityMain")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("clientdetails")).click();
	    Thread.sleep(2000);
	    System.out.println(driver.findElement(By.xpath(".//*[@id='content']/div[1]/div[1]")).getText());
	    driver.findElement(By.id("uploadentities")).click();
	    Thread.sleep(2000);
	    System.out.println(driver.findElement(By.xpath("//*[@id='content']/div[1]")).getText());
	    System.out.println("Successfully opened all the Entities menus");
	    
	  //Utilities
	    driver.findElement(By.id("UtilityMain")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("mainmenuProduct")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("subStandard")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("mainmenuEndofSale")).click();
	    Thread.sleep(2000);
	    System.out.println("Successfully opened all the Utilities menus");
	    
	    //Others
	    driver.findElement(By.id("mainmenuOthers")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("submenuGLAccounts")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("submenuContainer")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("submenuSundayCharge")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("submenuLetterHead")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.linkText("Layers")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.linkText("GST Rates")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.linkText("Supervisor Keys")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.linkText("Credit Classes")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.linkText("Doc Generation")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("StatusLevel")).click();
	    Thread.sleep(2000);
	    System.out.println("Successfully opened all the Other menus");
	    
	  //Manage Website
	    driver.findElement(By.linkText("Manage Website")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("submenuAppSetting")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("mail")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("systemlog")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("sysMsg")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("nine")).click();
	    Thread.sleep(2000);
	    System.out.println("Successfully opened all the Manage website menus");
	    
	    //Locked Lots
	    driver.findElement(By.id("HyperLink72")).click();
	    Thread.sleep(2000);
	  //Supplier Rep
	    driver.findElement(By.id("HyperLink22")).click();
	    Thread.sleep(2000);
	  //Buyer request log
	    driver.findElement(By.id("HyperLink37")).click();
	    Thread.sleep(2000);
	        
	    System.out.println("Successfully opened all the menus");
	    
	    //Close the window
	    driver.quit();
	    
	    
	
	}
}
