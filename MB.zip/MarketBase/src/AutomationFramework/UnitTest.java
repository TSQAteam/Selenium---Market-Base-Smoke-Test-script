package AutomationFramework;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

public class UnitTest {
	
public static void main(String args[]) throws InterruptedException{
		
		WebDriver driver;
		
		System.setProperty("webdriver.gecko.driver", "E:\\Selenium\\geckodriver-v0.17.0-win64\\geckodriver.exe");
		
		driver = new FirefoxDriver();
		 
	    //Put a Implicit wait, this means that any search for elements on the page could take the time the implicit wait is set for before throwing exception

        // driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	    //Launch the Online Store Website

	    driver.get("http://192.168.0.9:94");
	    
	    //user name
	    driver.findElement(By.id("MainContent_LoginForm1_UserName")).sendKeys("clive");
	    	    
	    //Password
	    
	    driver.findElement(By.id("MainContent_LoginForm1_Password")).sendKeys("Vss@1234");
	    
	    //Submit
	    
	    driver.findElement(By.name("ctl00$MainContent$LoginForm1$ctl01")).click();
	    
	    System.out.println("Success fully logged IN");
	    Thread.sleep(3000);
	    
	  //Home
	    System.out.println("Home screen text: "  + driver.findElement(By.id("content")).getText());
	    
	    driver.manage().window().maximize();
	    Thread.sleep(2000);
	    
	    //My Account
	    driver.findElement(By.linkText("My Account")).click();
	    System.out.println(driver.findElement(By.xpath(".//*[@id='content']/hgroup/h1")).getText());
	    Thread.sleep(5000);
	    
	    //Receivals
	    driver.findElement(By.linkText("Receivals")).click();
	    System.out.println(driver.findElement(By.xpath(".//*[@id='content']/div[1]/div[2]/div/div[1]/span")).getText());
	    Thread.sleep(2000);
	    
	  //SalesbyBuyer
	    driver.findElement(By.linkText("Sales by Buyer")).click();
	    System.out.println(driver.findElement(By.xpath(".//*[@id='content']/div[1]/div[2]/div/div[1]/span")).getText());
	    Thread.sleep(2000);
	    
	   //SalesbyLot
	    driver.findElement(By.linkText("Sales by Lot")).click();
	    System.out.println(driver.findElement(By.xpath(".//*[@id='content']/div[1]/div[2]/div/div/span")).getText());
	    Thread.sleep(2000);
	    
	  //Sales Analysis
	    driver.findElement(By.linkText("Sales Analysis")).click();
	    System.out.println(driver.findElement(By.xpath(".//*[@id='content']/div[1]/div[2]/div[1]")).getText());
	    Thread.sleep(2000);
	    System.out.println("Successfully opened all the main menus");
	    
	  //Reports
	    driver.findElement(By.linkText("Reports")).click();
	    Thread.sleep(1000);
	    driver.findElement(By.id("submenustockreport")).click();
	    System.out.println(driver.findElement(By.cssSelector("#content > div.table-container > form > div.table-main > div.portlet-header.fixed")).getText());
	    Thread.sleep(2000);
	    driver.findElement(By.id("submenuSalesAnalysis")).click();
	    System.out.println(driver.findElement(By.xpath(".//*[@id='content']/div[1]/div/div[1]")).getText());
	    Thread.sleep(2000);
	    driver.findElement(By.id("submenuTransactionBullet")).click();
	    System.out.println(driver.findElement(By.xpath(".//*[@id='content']/div[2]/div[2]/div[1]")).getText());
	    Thread.sleep(2000);
	    driver.findElement(By.id("submenuPrintSalesInvoices")).click();
	    System.out.println(driver.findElement(By.xpath(".//*[@id='content']/div[1]/div[2]/div")).getText());
	    Thread.sleep(2000);
	    driver.findElement(By.id("submenuPrintGrowerDocs")).click();
	    System.out.println(driver.findElement(By.xpath(".//*[@id='content']/div[1]/div[2]/div")).getText());
	    Thread.sleep(2000);
	    driver.findElement(By.id("submenuConsignmentStatusReport")).click();
	    System.out.println(driver.findElement(By.xpath(".//*[@id='content']/div[1]/div[2]/div[1]/div[1]/span")).getText());
	    Thread.sleep(2000);
	    driver.findElement(By.id("submenuProduceBalancingReport")).click();
	    System.out.println(driver.findElement(By.xpath(".//*[@id='content']/div[1]/div[2]/div[1]/div[1]/span")).getText());
	    Thread.sleep(2000);
	    System.out.println("Successfully opened all the Reports menus");
	    
	    //Utilities
	    driver.findElement(By.linkText("Utilities")).click();
	    Thread.sleep(1000);
	    driver.findElement(By.id("submenuProducttype")).click();
	    System.out.println(driver.findElement(By.xpath(".//*[@id='content']/div[1]/div[1]/div[1]")).getText());
	    Thread.sleep(2000);
	    driver.findElement(By.id("submenuProductVariety")).click();
	    System.out.println(driver.findElement(By.xpath(".//*[@id='content']/div[1]/div[1]/div[1]")).getText());
	    Thread.sleep(2000);
	    driver.findElement(By.id("submenuContainer")).click();
	    System.out.println(driver.findElement(By.xpath(".//*[@id='content']/div[1]/div[1]/div[1]")).getText());
	    Thread.sleep(2000);
	    System.out.println("Successfully opened all the utilities menus");
	    
	    //User Name
	    System.out.println(driver.findElement(By.xpath(".//*[@id='LoginView1']/loggedintemplate/div/h5/span")).getText());
	    Thread.sleep(1000);
	    
	    //Log off
	    WebElement element = driver.findElement(By.className("adminlogin"));
	    Actions action = new Actions(driver);
	    action.moveToElement(element).build().perform();
	    driver.findElement(By.linkText("Log off")).click();
	    System.out.println("Successfully Logged off");
	  
	    //Close the window
	    driver.quit();

}

}
