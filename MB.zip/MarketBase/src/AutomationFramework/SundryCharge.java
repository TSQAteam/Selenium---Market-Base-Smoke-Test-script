package AutomationFramework;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class SundryCharge {
	
	public static void main(String args[]) throws InterruptedException{
		
		WebDriver driver;
		
		System.setProperty("webdriver.gecko.driver", "E:\\Selenium\\geckodriver-v0.17.0-win64\\geckodriver.exe");
		
		driver = new FirefoxDriver();
		 
	    //Put a Implicit wait, this means that any search for elements on the page could take the time the implicit wait is set for before throwing exception

//	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	    //Launch the Online Store Website

	    driver.get("http://192.168.0.9:94");
	    
	    //user name
	    driver.findElement(By.id("MainContent_LoginForm1_UserName")).sendKeys("clive");
	    	    
	    //Password
	    
	    driver.findElement(By.id("MainContent_LoginForm1_Password")).sendKeys("Vss@1234");
	    
	    //Submit
	    
	    driver.findElement(By.name("ctl00$MainContent$LoginForm1$ctl01")).click();
	    
	    System.out.println("Success fully logged IN");
	    Thread.sleep(20);
	    
	    //Click users
	    
	    driver.findElement(By.partialLinkText("Users")).click();
	    
//	    driver.findElement(By.id("one")).click();
	    
	    driver.findElement(By.id("ContentPlaceHolderMainContent_GrdViewUsers_lnkShowPortal_3")).click();
	    
	    //Receivals add
	    
	    driver.findElement(By.id("ConsignMenu")).click();
	    driver.findElement(By.linkText("Add New")).click();
//	    driver.findElement(By.className("consign-add")).click();
	    //select suppliers
	    Thread.sleep(5);
//	    driver.findElement(By.id("EntitySuplier")).click();
//	    driver.findElement(By.id("lstSupplier_DDD_L_LBI3T0")).click();
	    driver.findElement(By.xpath(".//*[@id='lstSupplier_DDD_L_LBI3T0']")).click();
//	    driver.findElement(By.name("103 - Guiseppe Trovato Fruit Shop")).click();
	    driver.findElement(By.xpath(".//*[@id='GetEntityPopup_PWC-1']/div[4]/input[1]")).click();
	    //consign-add-Receival
	    driver.findElement(By.linkText("Add New")).click();
//	    driver.findElement(By.className("consign-add-Receival")).click();
	    Thread.sleep(20);
	    //Product type
	    driver.findElement(By.xpath(".//*[contains(@id,'ProdTypeId_DDD_L_LBI7T0')]")).click();
	    driver.findElement(By.xpath(".//*[@id='VarietyId_DDD_L_LBI3T0']")).click();
//	    Select dropdown = new Select(driver.findElement(By.name("ProdTypeId_VI")));
//	    dropdown.selectByValue("102176");
//	    dropdown.selectByVisibleText("Avocado");
//	    dropdown.selectByIndex(5);
	    
	    //driver.findElement(By.name("ProdTypeId")).sendKeys("Avocado"); 
//	    driver.findElement(By.id("ProdTypeId_DDD_L_LBI7T0")).click();
//	    driver.findElement(By.id("VarietyId_I")).click();
	    Thread.sleep(5);
	    driver.findElement(By.id("VarietyId_DDD_L_LBI3T0")).click();
	    //quantity, Price
	    driver.findElement(By.id("BuyCtnQty_I")).sendKeys("100");
	    driver.findElement(By.id("BuyPrice")).sendKeys("45");
	    driver.findElement(By.id("RepId_I")).click();
	    driver.findElement(By.id("RepId_DDD_L_LBI2T0")).click();
	    
	    
  
   
	    
	    
	    
	    
//	    Select dropdown = new Select(driver.findElement(By.id("lstSupplier_I")));
//	    
//	    dropdown.selectByVisibleText("103 - Guiseppe Trovato Fruit Shop");
	    
	    
	   
	    
	}
	
	

}
